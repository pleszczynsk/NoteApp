package com.pawelleszczynski.noteapp

class Note(nodeID: Int, nodeName: String, nodeDes: String) {

    var nodeID: Int? = nodeID
    var nodeName: String? = nodeName
    var nodeDes: String? = nodeDes

}